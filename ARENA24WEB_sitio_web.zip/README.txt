# ARENA 24 WEB — paquete inicial listo para publicar

Incluye:
- index.html: portada responsive.
- styles.css: identidad visual y diseño responsive.
- app.js: interacción básica del reproductor y menú móvil.
- assets/: logo/imagen de marca.

## Antes de publicar
1. Reemplazar el botón de radio por la URL real del streaming.
2. Cambiar los enlaces # de redes sociales por las cuentas oficiales.
3. Agregar correo/WhatsApp real de contacto.
4. Conectar las tarjetas de noticias a WordPress, un CMS o una API si se desea actualización automática.
5. Revisar y actualizar titulares antes de publicarlos.

## Marca propuesta
ARENA 24 WEB
Slogan: “La Rioja, todo el día.”
Promesa: “Informamos. Conectamos. Acompañamos.”
