const btn=document.getElementById('playBtn');const status=document.getElementById('playerStatus');
let playing=false;
btn.addEventListener('click',()=>{playing=!playing;btn.textContent=playing?'❚❚':'▶';status.textContent=playing?'Reproducción activa (configurá aquí la URL del streaming)':'Listo para reproducir';});
document.querySelector('.menu')?.addEventListener('click',()=>{const nav=document.querySelector('.nav nav');nav.style.display=nav.style.display==='flex'?'none':'flex';nav.style.position='absolute';nav.style.top='78px';nav.style.left='0';nav.style.right='0';nav.style.padding='20px';nav.style.background='#0d1b2a';nav.style.flexDirection='column';});
